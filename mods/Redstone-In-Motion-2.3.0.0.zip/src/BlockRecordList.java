package JAKJ . RedstoneInMotion ;

public class BlockRecordList extends java . util . ArrayList < BlockRecord >
{
}
