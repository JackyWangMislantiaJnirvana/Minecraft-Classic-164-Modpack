package JAKJ . RedstoneInMotion ;

public class BlockRecordSet extends java . util . TreeSet < BlockRecord >
{
}
